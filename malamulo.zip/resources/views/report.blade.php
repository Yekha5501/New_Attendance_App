@extends('layouts.app')

@section('content')
<div class="min-h-screen flex items-center justify-center bg-gray-200">
    <div class="w-full max-w-md">
        <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mt-4 mb-4">
            <h2 class="text-center font-bold mb-6">Download Student Results by Program</h2>
            <form action="{{ route('download.excel') }}" method="GET">
                <div class="flex flex-wrap -mx-3 mb-6">
                    <div class="w-full px-3 mb-6 md:mb-0">
                        <label for="program" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Select Program:</label>
                        <div class="relative">
                          <select name="program" id="program" class="block appearance-none w-full bg-gray-200 border border-gray-200 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white" size="5">
    <option value="CCM 1A">CCM 1A</option>
    <option value="CCM 1B">CCM 1B</option>
    <option value="CCM 2A">CCM 2A</option>
    <option value="CCM 2B">CCM 2B</option>
    <option value="CCM 2C">CCM 2C</option>
    <option value="MLS 2B">MLS 2B</option>
    <option value="MLS 3A">MLS 3A</option>
    <option value="DCM 1A">DCM 1A</option>
    <option value="DCM 1B">DCM 1B</option>
    <option value="DCM 2A">DCM 2A</option>
    <option value="DCM 2B">DCM 2B</option>
    <option value="DCM 3A">DCM 3A</option>
    <option value="DCM 3B">DCM 3B</option>
    <option value="PH 1A">PH 1A</option>
    <option value="PH 1B">PH 1B</option>
    <option value="PH 2A">PH 2A</option>
    <option value="PH 3B">PH 3B</option>
    <option value="PH 4A">PH 4A</option>
    <option value="NMT 1A">NMT 1A</option>
    <option value="NMT 1B">NMT 1B</option>
    <option value="NMT 2A">NMT 2A</option>
    <option value="NMT 2B">NMT 2B</option>
    <option value="NMT 3A">NMT 3A</option>
    <option value="NMT 3B">NMT 3B</option>
    <option value="BMLS 2A">BMLS 2A</option>
    <option value="BMLS 2B">BMLS 2B</option>
    <option value="BMLS 3A">BMLS 3A</option>
    <option value="BMLS 3B">BMLS 3B</option>
    <option value="BMLS 4A">BMLS 4A</option>
    <option value="BMS 1A">BMS 1A</option>
    <option value="BMS 1B">BMS 1B</option>
    <option value="BMS 2A">BMS 2A</option>
    <option value="BMS 2B">BMS 2B</option>
    <option value="BMS 3A">BMS 3A</option>
    <option value="BMS 3B">BMS 3B</option>
    <option value="BSC NMT 2A">BSC NMT 2A</option>
    <option value="BSNM">BSNM</option>
    <option value="DCMME">DCMME</option>
    <option value="BMLS">BMLS</option>
</select>

                            <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                    <path d="M7 10l5 5 5-5H7z" />
                                </svg>
                            </div>
                        </div>
                    </div>
                    <div class="w-full px-3 mt-4">
                        <button type="submit" class="w-full bg-orange-500 hover:bg-orange-700 text-white font-bold py-2 px-4 rounded">Download Excel</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
