<?php return array (
  'another-card' => 'App\\Http\\Livewire\\AnotherCard',
  'attendance-graph' => 'App\\Http\\Livewire\\AttendanceGraph',
  'attendance-percentage' => 'App\\Http\\Livewire\\AttendancePercentage',
  'donut-chart' => 'App\\Http\\Livewire\\DonutChart',
  'line-graph' => 'App\\Http\\Livewire\\LineGraph',
  'mobile-users-list' => 'App\\Http\\Livewire\\MobileUsersList',
  'total-attendees-card' => 'App\\Http\\Livewire\\TotalAttendeesCard',
  'total-students-card' => 'App\\Http\\Livewire\\TotalStudentsCard',
  'total-worship-sessions' => 'App\\Http\\Livewire\\TotalWorshipSessions',
);