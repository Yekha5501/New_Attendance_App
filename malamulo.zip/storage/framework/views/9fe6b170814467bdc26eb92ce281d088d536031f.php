<?php $__env->startSection('content'); ?>

<head>
    <!-- Other head content -->
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <style>
        /* Custom CSS for spacing on small screens */
        .row {
            display: flex;
            flex-wrap: wrap;
            margin: -0.5rem; /* Adjust this value to control spacing between columns */
        }
        .col-md-4,
        .col-md-8 {
            padding: 0.5rem; /* Adjust this value to control spacing between columns */
            box-sizing: border-box;
        }
        @media (max-width: 768px) {
            .col-md-4,
            .col-md-8 {
                width: 100%;
                margin-bottom: 1rem; /* Space between stacked columns on small screens */
            }
        }
        @media (min-width: 769px) {
            .col-md-4 {
                flex: 1 0 33.3333%; /* 3 columns of equal width on medium screens */
            }
            .col-md-8 {
                flex: 1 0 66.6666%; /* 2 columns with 2/3 width on medium screens */
            }
        }
    </style>
</head>

<div class="mx-auto bg-gray-200 p-4 px-12">
    <div class="row mb-4">
        <div class="col-md-4"><?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('total-students-card')->html();
} elseif ($_instance->childHasBeenRendered('YhBIpYr')) {
    $componentId = $_instance->getRenderedChildComponentId('YhBIpYr');
    $componentTag = $_instance->getRenderedChildComponentTagName('YhBIpYr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YhBIpYr');
} else {
    $response = \Livewire\Livewire::mount('total-students-card');
    $html = $response->html();
    $_instance->logRenderedChild('YhBIpYr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
        <div class="col-md-4"><?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('total-worship-sessions')->html();
} elseif ($_instance->childHasBeenRendered('iqAFeAq')) {
    $componentId = $_instance->getRenderedChildComponentId('iqAFeAq');
    $componentTag = $_instance->getRenderedChildComponentTagName('iqAFeAq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('iqAFeAq');
} else {
    $response = \Livewire\Livewire::mount('total-worship-sessions');
    $html = $response->html();
    $_instance->logRenderedChild('iqAFeAq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
        <div class="col-md-4"><?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('attendance-percentage')->html();
} elseif ($_instance->childHasBeenRendered('2ZndOcN')) {
    $componentId = $_instance->getRenderedChildComponentId('2ZndOcN');
    $componentTag = $_instance->getRenderedChildComponentTagName('2ZndOcN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2ZndOcN');
} else {
    $response = \Livewire\Livewire::mount('attendance-percentage');
    $html = $response->html();
    $_instance->logRenderedChild('2ZndOcN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
    </div>
    <div class="row">
        <div class="col-md-8"><?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('attendance-graph')->html();
} elseif ($_instance->childHasBeenRendered('Sc7mJcU')) {
    $componentId = $_instance->getRenderedChildComponentId('Sc7mJcU');
    $componentTag = $_instance->getRenderedChildComponentTagName('Sc7mJcU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Sc7mJcU');
} else {
    $response = \Livewire\Livewire::mount('attendance-graph');
    $html = $response->html();
    $_instance->logRenderedChild('Sc7mJcU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
        <div class="col-md-4"><?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('donut-chart')->html();
} elseif ($_instance->childHasBeenRendered('G6Wpksk')) {
    $componentId = $_instance->getRenderedChildComponentId('G6Wpksk');
    $componentTag = $_instance->getRenderedChildComponentTagName('G6Wpksk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('G6Wpksk');
} else {
    $response = \Livewire\Livewire::mount('donut-chart');
    $html = $response->html();
    $_instance->logRenderedChild('G6Wpksk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/1292223.cloudwaysapps.com/ufhsfcheqd/public_html/resources/views/home.blade.php ENDPATH**/ ?>