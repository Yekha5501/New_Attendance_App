<!-- resources/views/livewire/total-students-card.blade.php --><div class="bg-blue-100 p-4 rounded-lg shadow-md flex items-center justify-between">
    <div>
        <h2 class="text-lg font-semibold">Total Students</h2>
        <div class="flex items-center justify-center bg-white rounded-full p-2 mt-4">
            <p class="text-orange-400 text-2xl font-bold"><?php echo e($totalStudents); ?></p>
        </div>
    </div>
    <div class="bg-blue-200 p-2 rounded-full">
        <i class="fas fa-users text-4xl text-blue-500"></i>
    </div>
</div>

<?php /**PATH /home/1292223.cloudwaysapps.com/ufhsfcheqd/public_html/resources/views/livewire/total-students-card.blade.php ENDPATH**/ ?>