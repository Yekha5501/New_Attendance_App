<?php

namespace App\Http\Controllers;

use App\Exports\StudentsExportbyProgram;
use App\Exports\StudentsExport;
use App\Models\Worship;
use App\Models\Student;
use App\Models\WorshipSession;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\StudentsExportPhpSpreadsheet;
use PDF;


class WorshipSessionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */



    public function report()
    {
        return view('report');
    }

    public function exportToExcel()
    {
        $export = new StudentsExportPhpSpreadsheet();
        return $export->export();
    }

    public function downloadExcel(Request $request)
    {
        $program = $request->input('program');

        $exporter = new StudentsExportbyProgram($program);
        return $exporter->export();
    }

    
public function export()
    {
        $exporter = new StudentsExport();
        return $exporter->export();
    }


public function show()
{
    // Fetch all worship sessions and order them by status ('Progress' first)
    $worshipSessions = WorshipSession::orderByRaw("FIELD(status, 'Progress', 'Completed')")->get();

    // Fetch attendance records for each worship session
    foreach ($worshipSessions as $worshipSession) {
        $worshipSession->attendanceRecords = Worship::where('worship_session_id', $worshipSession->id)->get();
    }

    return view('worship-sessions.show', ['worshipSessions' => $worshipSessions]);
}




    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('worship-sessions.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            // Check if there is any session in progress
            $sessionInProgress = WorshipSession::where('status', 'Progress')->exists();

            if ($sessionInProgress) {
                return redirect()->back()->with('error', 'Cannot create a new session while there is one in progress.');
            }

            // Validate the request data
            $validatedData = $request->validate([
                'title' => 'required|string',
                'date' => 'required|date',
                'type' => 'required|in:Morning,Evening',
            ]);

            // Generate a random worship session ID starting with "MAU"
            $worshipSessionId = 'MAU' . rand(1000, 9999); // Example: MAU1234

            // Create a new worship session
            $worshipSession = new WorshipSession();
            $worshipSession->worship_session_id = $worshipSessionId;
            $worshipSession->title = $validatedData['title'];
            $worshipSession->date = $validatedData['date'];
            $worshipSession->type = $validatedData['type'];
            $worshipSession->status = 'Progress'; // Set status to Progress
            $worshipSession->save();

            // Redirect back with a success message
            return redirect()->back()->with('success', 'Worship session created successfully');
        } catch (\Exception $e) {
            // Log the error
            \Log::error('Error creating worship session: ' . $e->getMessage());

            // Redirect back with an error message
            \Session::put('error', 'Cannot create a new session while there is one in progress.');
            return redirect()->back();
        }
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function markSession($id)
    {
        $worshipSession = WorshipSession::findOrFail($id);
        $worshipSession->status = 'Completed';
        $worshipSession->save();

        return redirect()->back()->with('success', 'Worship session marked as completed.');
    }

    public function setProgress($id)
    {
        $worshipSession = WorshipSession::findOrFail($id);
        $worshipSession->status = 'Progress';
        $worshipSession->save();

        return redirect()->back()->with('success', 'Worship session set back to Progress.');
    }

    public function finalReport()
    {
        // Fetch all students
        $students = Student::all();

        // Fetch all worship sessions with their dates
        $worshipSessions = WorshipSession::select('id', 'date')->get();

        // Create an array to store attendance records
        $attendanceRecords = [];

        foreach ($students as $student) {
            // Initialize attendance array with 0 for each worship date
            $attendance = array_fill_keys($worshipSessions->pluck('date')->toArray(), 0);

            // Fetch attendance records for the student
            $studentAttendances = Worship::where('student_id', $student->id)->get();

            foreach ($studentAttendances as $record) {
                // Mark attendance as 1 for the specific date
                $sessionDate = $worshipSessions->firstWhere('id', $record->worship_session_id)->date;
                $attendance[$sessionDate] = 1;
            }

            // Add the student and their attendance record to the array
            $attendanceRecords[] = [
                'student' => $student,
                'attendance' => $attendance,
            ];
        }

        return view('reports.final', compact('attendanceRecords', 'worshipSessions'));
    }



    public function PdfReport()
    {
        $students = Student::all();
        $worshipSessions = WorshipSession::all();

        $data = $students->map(function ($student) use ($worshipSessions) {
            $attendance = $worshipSessions->mapWithKeys(function ($session) use ($student) {
                $worship = Worship::where('student_id', $student->id)
                    ->where('worship_session_id', $session->id)
                    ->first();
                return [$session->id => $worship ? 1 : 0];
            });

            return [
                'first_name' => $student->First_name,
                'surname' => $student->Surname,
                'registration_number' => $student->registration_number,
                'attendance' => $attendance,
                'average_grade' => $student->avg_grade,
            ];
        });

        $pdf = PDF::loadView('student.pdf', compact('data', 'worshipSessions'));
        return $pdf->download('students.pdf');
    }
}
