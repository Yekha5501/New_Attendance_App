<?php

namespace App\Http\Livewire;

use Livewire\Component;

class LineGraph extends Component
{
    public function render()
    {
        return view('livewire.line-graph');
    }
}
