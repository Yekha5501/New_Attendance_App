<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\WorshipSession;
use App\Models\Worship;
use App\Models\Student;

class AttendancePercentage extends Component
{
    public $attendancePercentage;

    public function mount()
    {
        $this->calculateAttendancePercentage();
    }

    public function calculateAttendancePercentage()
    {
        // Get the latest worship session
       
         $latestSession = WorshipSession::latest()->first();

        if ($latestSession) {
            // Calculate total students
            $totalStudents = Student::count();
            // Calculate attended students
            $attendedStudents = Worship::where('worship_session_id', $latestSession->id)->where('attendance', 1)->count();

            // Calculate the attendance percentage and round to the nearest whole number
            $this->attendancePercentage = $totalStudents > 0 ? round(($attendedStudents / $totalStudents) * 100) : 0;
        } else {
            $this->attendancePercentage = 0;
        }
    }

    public function render()
    {
        return view('livewire.attendance-percentage');
    }
}
